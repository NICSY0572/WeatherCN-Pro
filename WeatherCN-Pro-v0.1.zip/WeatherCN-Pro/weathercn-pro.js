/*
WeatherCN Pro v0.1.0
阶段目标：先打通 Loon -> Apple Weather 响应拦截链路。
说明：此版本只做安全注入和日志，不破坏原始天气数据。
*/

const VERSION = "0.1.0";
const TAG = "WeatherCN Pro";

function log(msg) {
  console.log(`[${TAG}] ${msg}`);
}

function safeParseJSON(text) {
  try { return JSON.parse(text); } catch (_) { return null; }
}

function main() {
  const url = $request.url || "";
  let body = $response.body || "";

  log(`version=${VERSION}`);
  log(`url=${url}`);

  const json = safeParseJSON(body);
  if (!json) {
    log("response is not JSON, skip");
    return $done({ body });
  }

  // 调试标记：只用于确认脚本生效。天气 App 通常不会显示这个字段。
  json.weatherCNPro = {
    enabled: true,
    version: VERSION,
    stage: "intercept-test",
    url,
    timestamp: new Date().toISOString()
  };

  log("inject success");
  return $done({ body: JSON.stringify(json) });
}

main();
