# WeatherCN-Pro

中国版 iPhone 天气增强插件，适用于 Loon。

## 当前版本

v0.1.0：拦截链路测试版。

## Loon 订阅地址

```text
https://raw.githubusercontent.com/NICSY0572/WeatherCN-Pro/main/WeatherCN.plugin
```

## 当前功能

- 拦截 `weatherkit.apple.com`
- 拦截 `weather-data.apple.com`
- 输出调试日志
- 不破坏原始 Apple 天气数据

## 下一步

- 下一小时降水模块
- 空气质量增强模块
- 国内天气预警模块
